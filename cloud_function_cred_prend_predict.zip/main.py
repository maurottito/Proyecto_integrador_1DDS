import requests
import pickle
from google.cloud import storage
import numpy as np

storage_client = storage.Client()
bucket = storage_client.get_bucket('model-mauro-v1')
blob = bucket.blob('classifier.pickle')
blob.download_to_filename('/tmp/classifier.pickle')
model_pk = pickle.load(open('/tmp/classifier.pickle', 'rb'))

def api_predict_cred_prend(request):
    if request.method == 'GET':
        return "Please Send POST Request"
    elif request.method == 'POST':
        
        data = request.get_json()
        
        Edad = data["Edad"]
        Sexo = data["Sexo"]
        CantCred = data["CantCred"]
        SalVigSol = data["SalVigSol"]
        DiasEfec = data["DiasEfec"]
        MaxDeuda = data["MaxDeuda"]
        MaxDiasAtra = data["MaxDiasAtra"]
        EstaCiv_cas = data["EstaCiv_cas"]
        EstaCiv_con = data["EstaCiv_con"]
        EstaCiv_div = data["EstaCiv_div"]
        EstaCiv_sep = data["EstaCiv_sep"]
        EstaCiv_sol = data["EstaCiv_sol"]
        TipoViv_alq = data["TipoViv_alq"]
        TipoViv_def = data["TipoViv_def"]
        TipoViv_pro = data["TipoViv_pro"]

        data = np.array([[ Edad, Sexo, CantCred, SalVigSol, DiasEfec, MaxDeuda, MaxDiasAtra, 
                            EstaCiv_cas, EstaCiv_con, EstaCiv_div, EstaCiv_sep, EstaCiv_sol, 
                            TipoViv_alq, TipoViv_def, TipoViv_pro]])
           
        prediction = model_pk.predict(data)
        return str(prediction)
